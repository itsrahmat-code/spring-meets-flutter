package com.rahmatullahsaruk.stock_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
